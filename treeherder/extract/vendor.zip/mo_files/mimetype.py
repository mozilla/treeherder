from mo_future import text

JSON = text("application/json")
ZIP = text("application/zip")
