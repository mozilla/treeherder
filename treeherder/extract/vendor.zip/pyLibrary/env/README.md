
# Environment

This directory is for connecting to other systems. Generally, these
classes are facades that assume content is UTF-8 encoded JSON.



## emailer

A simple emailer, the primary purpose is to accept a [Data](https://github.com/klahnakoski/mo-dots/blob/dev/docs/README.md)
of settings.


## pulse

For connecting clients to [Mozilla's Pulse](https://pulse.mozilla.org/).


